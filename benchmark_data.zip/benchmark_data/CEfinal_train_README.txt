-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-

                      		FINAL DATA RELEASE
   
              Isabelle Guyon -- isabelle@clopinet.com -- June 2013
                                  
-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-o-|-

DISCLAIMER: ALL INFORMATION, SOFTWARE, DOCUMENTATION, AND DATA ARE PROVIDED "AS-IS" 
ISABELLE GUYON AND/OR OTHER CONTRIBUTORS DISCLAIM ANY EXPRESSED OR IMPLIED WARRANTIES, 
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
FOR ANY PARTICULAR PURPOSE, AND THE WARRANTY OF NON-INFRIGEMENT OF ANY THIRD PARTY'S 
INTELLECTUAL PROPERTY RIGHTS. IN NO EVENT SHALL ISABELLE GUYON AND/OR OTHER CONTRIBUTORS 
BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF SOFTWARE, DOCUMENTS, 
MATERIALS, PUBLICATIONS, OR INFORMATION MADE AVAILABLE FOR THE CHALLENGE. 

CONTENTS:

	FINAL DATA RELEASE JUNE 2013

CEfinal_train_text.zip: Validation data in csv format 
CEfinal_train_split.zip: Training data in split files format (one file per pair of variables)	
CEfinal_valid_text.zip: Validation data in csv format 
CEfinal_valid_split.zip: Validation data in split files format

ENCRYPTED DATA (ENCRYPTION KEY TO BE RELEASED AT THE CHALLENGE DEADLINE
CEfinal_test_text.zip: Final evaluation data in csv format 
CEfinal_test_split.zip: Final evaluation data in split files format (one file per pair of variables)	

[-------- WARNING : text and split versions are identical, download only one -------]

	 
